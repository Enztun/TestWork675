<?php
/**
 * Template Name: Countries and Cities Table
 * Description: A custom template to display a table of countries and cities.
 */

get_header(); ?>

<div id="countries-cities-table-container">
    <table id="countries-cities-table" class="display">
        <thead>
            <tr>
                <th>Country</th>
                <th>City</th>
                <th>Latitude</th>
                <th>Longitude</th>
                <th>Temperature</th>
            </tr>
        </thead>
        <tbody>
            <?php
            global $wpdb;
            $results = $wpdb->get_results(
                "
                SELECT 
                    p.ID, 
                    p.post_title AS city_name, 
                    pm_lat.meta_value AS latitude, 
                    pm_lng.meta_value AS longitude, 
                    pm_temp.meta_value AS temperature, 
                    t.name AS country
                FROM {$wpdb->posts} AS p
                LEFT JOIN {$wpdb->postmeta} AS pm_lat 
                    ON p.ID = pm_lat.post_id AND pm_lat.meta_key = 'latitude'
                LEFT JOIN {$wpdb->postmeta} AS pm_lng 
                    ON p.ID = pm_lng.post_id AND pm_lng.meta_key = 'longitude'
                LEFT JOIN {$wpdb->postmeta} AS pm_temp 
                    ON p.ID = pm_temp.post_id AND pm_temp.meta_key = 'temperature'
                LEFT JOIN {$wpdb->term_relationships} AS tr 
                    ON p.ID = tr.object_id
                LEFT JOIN {$wpdb->term_taxonomy} AS tt 
                    ON tr.term_taxonomy_id = tt.term_taxonomy_id
                LEFT JOIN {$wpdb->terms} AS t 
                    ON tt.term_id = t.term_id
                WHERE p.post_type = 'cities'
                AND p.post_status = 'publish'
                "
            );

            if (!empty($results)) {
                foreach ($results as $result) {
                    echo '<tr>';
                    echo '<td>' . esc_html($result->country) . '</td>';
                    echo '<td>' . esc_html($result->city_name) . '</td>';
                    echo '<td>' . esc_html($result->latitude) . '</td>';
                    echo '<td>' . esc_html($result->longitude) . '</td>';
                    echo '<td>' . esc_html($result->temperature) . '</td>';
                    echo '</tr>';
                }
            } else {
                echo '<tr><td colspan="5">No data found</td></tr>';
            }
            ?>
        </tbody>
    </table>
</div>


<?php get_footer(); ?>
