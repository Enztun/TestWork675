jQuery(document).ready(function ($) {
    const searchField = document.getElementById("cities-search");
    const tableContainer = document.getElementById("countries-cities-table-container");

    let dataTable = null; // Store the DataTable instance

    // Initialize DataTable function
    function initializeDataTable() {
        if (document.querySelector("#countries-cities-table")) {
            dataTable = $("#countries-cities-table").DataTable({
                paging: true,
                searching: false, // Disable built-in search
                ordering: true,
                info: true,
            });
        }
    }

    // Destroy DataTable safely
    function destroyDataTable() {
        if (dataTable) {
            dataTable.clear(); // Clear data
            dataTable.destroy(); // Destroy instance
            dataTable = null; // Reset variable
        }
    }

    // Handle search field input
    if (searchField && tableContainer) {
        searchField.addEventListener("input", function () {
            const searchQuery = searchField.value.trim();

            // Make the AJAX request
            fetch(storefront_cities_ajax.ajax_url, {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded",
                },
                body: new URLSearchParams({
                    action: "search_cities",
                    search_query: searchQuery,
                }),
            })
                .then((response) => {
                    if (!response.ok) throw new Error("Network response was not ok");
                    return response.text(); // Expecting HTML for the table body
                })
                .then((data) => {
                    destroyDataTable(); // Destroy existing DataTable
                    const tableBody = document.querySelector("#countries-cities-table tbody");
                    if (tableBody) {
                        tableBody.innerHTML = data; // Update the table content
                        initializeDataTable(); // Reinitialize DataTable
                    }
                })
                .catch((error) => console.error("AJAX Error:", error));
        });
    }

    // Initialize DataTable on page load
    initializeDataTable();
});
