jQuery(document).ready(function ($) {
    $('#cities-search').on('keyup', function () {
        const searchQuery = $(this).val();

        $.ajax({
            url: storefront_cities_ajax.ajax_url,
            method: 'POST',
            data: {
                action: 'search_cities',
                search_query: searchQuery,
            },
            success: function (response) {
                if (response.success) {
                    $('#countries-cities-table-container tbody').html(response.data);
                } else {
                    console.error(response.data);
                }
            },
            error: function (err) {
                console.error(err);
            },
        });
    });
});
